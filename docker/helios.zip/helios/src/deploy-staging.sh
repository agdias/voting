#!/bin/bash
fab staging_deploy:tag=latest,hosts="server1.heliosvoting.org"