# Helios Election System

Helios is an end-to-end verifiable voting system.


![Travis Build Status](https://travis-ci.org/wrmack/helios-server.svg?branch=wm-python3-django2)


This branch uses Python 3.7, Django 2.2 and Celery 4.3

I am developing documentation here, which includes installation instructions: [Helios Server documentation](https://wrmack.github.io/helios-server-docs/site/)