"""
This django app is meant only to connect the pieces of Helios and Auth to present a clean UI
"""

# from server_ui import glue
