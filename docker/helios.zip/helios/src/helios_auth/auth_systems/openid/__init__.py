"""
OpenID utils

some copied from http://github.com/openid/python-openid/examples/djopenid

ben@adida.net
"""
